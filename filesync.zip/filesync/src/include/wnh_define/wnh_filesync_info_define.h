#ifndef __wnh_filesync_info_define__
#define __wnh_filesync_info_define__

#define WNH_FILESYNC_USE_HELP  "If you have any questions, you can contact wunanhui_1@126.com by email."
#define WNH_FILESYNC_COPYRIGHT "----------Copyright 2018-2019 WuNanhui. All rights reserved.-----------"

#endif
