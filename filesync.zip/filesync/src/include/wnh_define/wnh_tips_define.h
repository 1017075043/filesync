#ifndef __wnh_tips_define__
#define __wnh_tips_define__

#endif
